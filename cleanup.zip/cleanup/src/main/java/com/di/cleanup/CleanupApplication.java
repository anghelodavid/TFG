package com.di.cleanup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleanupApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleanupApplication.class, args);
	}

}
