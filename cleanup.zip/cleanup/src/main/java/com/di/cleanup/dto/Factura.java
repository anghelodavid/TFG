package com.di.cleanup.dto;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Factura {
	private long id;
	private LocalDate fecha;
	private float total;
	private long cliente_id;
	public static final Double PORCENTAJE_IVA = 0.21; // 21% de IVA
	
	protected Factura(long id, LocalDate fecha, float total, long cliente_id) {
		super();
		this.id = id;
		this.fecha = fecha;
		this.total = total;
		this.cliente_id = cliente_id;
	}
	public Factura() {
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public LocalDate getFecha() {
		return fecha;
	}
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public long getCliente_id() {
		return cliente_id;
	}
	public void setCliente_id(long cliente_id) {
		this.cliente_id = cliente_id;
	}
	public static Double getPorcentajeIva() {
		return PORCENTAJE_IVA;
	}
	
}