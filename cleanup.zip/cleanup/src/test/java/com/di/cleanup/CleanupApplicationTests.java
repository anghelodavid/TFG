package com.di.cleanup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanupApplicationTests {

	@Test
	void contextLoads() {
	}

}
